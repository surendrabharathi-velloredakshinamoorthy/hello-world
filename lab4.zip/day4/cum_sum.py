mylist = [1,2,3]
newlist = []
variable = 0
for i in range (0,len(mylist)):
	variable = variable + mylist[i]
	newlist.append(variable)
print (newlist)


