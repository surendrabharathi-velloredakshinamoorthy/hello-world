def print_hist(h):
	for c in h:
		print (c,h[c])


print_hist("sdsd")
