mylist = [1,2,3,4,5,6,7,7,1,9]

def remove_duplicate():
	print(list(set(mylist)))



remove_duplicate()
