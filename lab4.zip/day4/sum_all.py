
def sum_all(*args):
	print (sum(args))


sum_all(1,2,3)
