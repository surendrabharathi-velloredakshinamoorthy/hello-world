f = open('words.txt.1', 'r')
print (f.read())
f.close()
