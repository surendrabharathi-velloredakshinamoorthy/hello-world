def nested_sum():
	sumlist = 0
	mylist = [1,2,3,1,4]

	for num in mylist:
		sumlist = sumlist + num
	print(sumlist)



nested_sum()
